package algo.trader.endpoints;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import algo.trader.domain.Employee;

@RestController

public class EmployeeService {
	List<Employee> employees;
		
	public EmployeeService() {
		super();
		Employee emp= new Employee ("Mohan", "mohan@gamail.com");
		Employee emp2 = new Employee ("Ajay", "ajay@gmail.com");
		
		employees = new ArrayList<>();
		employees.add(emp);
		employees.add(emp2);

		}
	
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@RequestMapping(value="/employees", method = RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_XML_VALUE})
		public List<Employee> getEmployees(){
			return (employees);
		}
		
	@RequestMapping(value="/employees", method = RequestMethod.POST)
		public void addEmployee(@RequestBody Employee employee){
		employees.add(employee);
		log.info("Employee added "+ employees);
    	}
}
