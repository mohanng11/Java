package algo.trader.domain;

public enum Currency {
    USD, GBP, EUR, JPY;
}
