package domain;


public class Broker {
}
