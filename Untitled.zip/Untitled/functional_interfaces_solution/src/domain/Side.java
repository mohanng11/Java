package domain;


public enum Side {
    BUY, SELL;
}
