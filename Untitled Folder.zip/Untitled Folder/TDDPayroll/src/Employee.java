
public class Employee {

	private String name;
	
	public Employee(String name, int salary) {
		// TODO Auto-generated constructor stub
		this.salary=salary;
		this.name=name;
	}

	public int calcMonthlyPay() {
		// TODO Auto-generated method stub
		return this.salary;
	}

		
}
