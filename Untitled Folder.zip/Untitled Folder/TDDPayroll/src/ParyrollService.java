import java.util.List;
import java.util.Iterator;

public class ParyrollService {

	public static int calcMonthlyTotal(List<Employee> employees) {
		// TODO Auto-generated method stub
		total =0;
		
		for (Employee employee : employees) {
			
			total + = employee.calcMonthlyPay();
		}
		
		return 0;
	}

}
