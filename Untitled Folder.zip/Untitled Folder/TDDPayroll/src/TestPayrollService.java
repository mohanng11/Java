import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class TestPayrollService {

//	@Test
//	public void testPayrollService() {
//		List<Employee> employees =
//				Arrays.asList(new Employee ("Adam", 10000),
//						new Employee ("Brian", 20000),
//						new Employee ("Bob", 30000)
//			);
//				int total =ParyrollService.calcMonthlyTotal(employees);
//				
//				assertEquals(60000,total);
//				
//	}
	
	@Test
	public void testPayrollService() {
		List<Employee> employees =
				Arrays.asList(new FullTimeEmployee ("Adam", 10000),
						new FullTimeEmployee ("Brian", 20000),
						new FullTimeEmployee ("Bob", 30000)
			);
				int total =ParyrollService.calcMonthlyTotal(employees);
				
				assertEquals(60000,total);

	}
