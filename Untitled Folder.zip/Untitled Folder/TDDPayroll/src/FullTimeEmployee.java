
public class FullTimeEmployee extends Employee {

	public FullTimeEmployee(String string, int i) {
		// TODO Auto-generated constructor stub
		
		
	}

	
}
