package com.demo.params;

public class Calculator {
	public long add(int valueOne, int valueTwo){
		return valueOne+valueTwo;
	}

	public long subtract(int valueOne, int valueTwo){
		return valueOne-valueTwo;
	}
}
