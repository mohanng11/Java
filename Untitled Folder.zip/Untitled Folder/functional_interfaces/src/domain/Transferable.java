package domain;


public interface Transferable {

   default void transfer(Broker targetExchange){

   }
}
