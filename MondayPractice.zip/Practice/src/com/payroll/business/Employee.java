package com.payroll.business;

public abstract class Employee implements Comparable<Object> 
{
	private String name;
	private String email;
	
	public Employee(String name, String email) {
		this.email = email;
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "Name: " + name + ", email: " + email;
		//System.out.println("Name");
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public abstract double calcMonthlyPay() ;
	
	@Override
	public int compareTo(Object otherObject) {
		Employee empRef = (Employee) otherObject;
		
		
		
		return this.name.compareTo(empRef.name);
		
		
		
		
		
		
	}
	
	
}
