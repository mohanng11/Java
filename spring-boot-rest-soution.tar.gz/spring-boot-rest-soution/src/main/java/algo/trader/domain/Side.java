package algo.trader.domain;


public enum Side {
    BUY, SELL;
}
