package algo.trader.endpoints;


import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import algo.trader.domain.Employee;

@RestController

public class EmployeeService1 {
	List<Employee> employees = new ArrayList<>();
		
	public EmployeeService1() {
		employees.add(new Employee("David","david@gmail.com"));
		employees.add(new Employee("Rob","Rob@gmail.com"));
		employees.add(new Employee("jack","jack@gmail.com"));
		employees.add(new Employee("lee","lee@gmail.com"));

		}
	
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@RequestMapping(value="/employees1", method = RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_XML_VALUE})
		public List<Employee> getEmployees(){
			return employees;
		}
		
	@RequestMapping(value="/employees1", method = RequestMethod.POST)
		public Employee addEmployee(@RequestBody Employee newEmployee){
		this.employees.add(newEmployee);
		return newEmployee;
    	}
}
